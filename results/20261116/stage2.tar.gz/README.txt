Key evidence for the completed eight-device Jiuge4B parallel-layout E2E evaluation.

Stage2: TP4/PP2 and TP8/PP1, CPT and LoRA,48 full50step jobs,8 numeric arms,8 native save9/load9/continue10 pairs.
All control and measurement inputs are in evidence/. Frozen sources are in source-snapshot/.
The full model weights and tensor checkpoint bodies are NOT included. They followed the authorized container-local storage policy. Original model/data on the account NAS were not deleted.

CPU recheck after extracting the first-stage and this archive into separate directories stage1/ and stage2/:
python stage2/analysis/first-stage-review.py stage1/evidence stage1/original-numeric-protocol.json stage1/independent-result-review.json
python stage2/analysis/stage2-review.py stage2/evidence stage2/original-numeric-protocol.json stage2/independent-result-review.json
python stage2/analysis/aggregate-results.py stage1 stage2

First-stage archive: host-pool-key-evidence-20261116.tar.gz
SHA256:6465f54a7588d04da7b18e034ea9e29e02b9f178d931e16f379b8b1ae5e7fa0e
First-stage raw records are required for its independent CPU audit. Do not unpack the two evidence/ trees into the same directory.

These CPU commands recompute recorded evidence, not GPU performance. Fresh GPU reruns require the pinned CoreX5 environment, project source/dependencies and original model/data. Configs and exact commands are retained per run. Use new versioned output/checkpoint directories and a separately authorized resource deadline to preserve this evidence.

All preregistered samples remain in the final statistics, including the slow first TP2/PP4 LoRA baseline and the TP8 CPT storage/scheduling variability. The20:00 scheduling stop had no unpaired performance data; the final6TP8LoRA pairs ran after explicit continuation in the same container.
