from pathlib import Path
import datetime,hashlib,importlib.metadata,json,os,shutil,subprocess
import torch
B=Path('/private/yp/jiuge-training');H=B/'tools/host_pool_stage2_20261116';R=B/'checks/20261116-host-pool-stage2-v1';read=lambda p:json.loads(p.read_text())
assert not (R/'failure.json').exists()
assert read(R/'status.json')['state']=='budget_admission_stop'
assert len(list(R.glob('*-pair-??.json')))==18 and not list(R.glob('tp8-lora-pair-??.json'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in read(R/'protocol.json')['sources'].items())
oldenv=read(R/'environment-20261116-143538.json')
assert os.uname().nodename==oldenv['hostname'],'Require full new-environment preflight if pod changed'
assert torch.__version__==oldenv['torch'] and importlib.metadata.version('triton')==oldenv['triton'] and torch.cuda.device_count()==8
assert shutil.disk_usage(B).free>=22*2**30 and shutil.disk_usage('/tmp').free>=3000*2**30
assert 'No running processes found' in subprocess.check_output(['/usr/local/iluvatar/bin/ixsmi'],text=True)
now=datetime.datetime.now().astimezone();until=datetime.datetime.fromisoformat('2026-11-16T22:30:00+08:00')
cap=datetime.datetime.fromisoformat('2026-11-16T14:35:38+08:00')+datetime.timedelta(hours=8)
hard=min(until-datetime.timedelta(minutes=5),cap-datetime.timedelta(minutes=10));allowed=hard-datetime.timedelta(minutes=5)
assert now+datetime.timedelta(minutes=100)<hard,'Insufficient remaining time for six complete TP8LoRA pairs'
previous=read(R/'admission.json');(R/'resource-windows').mkdir(exist_ok=True)
(R/'resource-windows'/(previous['window_id']+'-admission-before-resume.json')).write_text(json.dumps(previous,indent=2)+'\n')
active={**previous,'window_id':'20261116-resume-'+now.strftime('%H%M%S'),'allowed_until':allowed.isoformat(),'hard_stop':hard.isoformat(),'platform_end':until.isoformat(),
    'authorization':'User explicitly instructed continue to finish and confirmed22.30 in chat','scope':'ONLY last TP8LoRA6pairs remain; prior18pairs sealed and retained; original64GPUh ceiling; no additional resource or platform modification'}
tmp=R/'admission.resume-pending';tmp.write_text(json.dumps(active,indent=2)+'\n');os.replace(tmp,R/'admission.json')
logpath=B/'checks'/('host-pool-stage2-resume-'+now.strftime('%Y%m%d-%H%M%S')+'.log')
log=logpath.open('x')
p=subprocess.Popen(['python',str(B/'tools/eight_gpu_20261113/corex5_exec.py'),'python',str(H/'campaign.py')],cwd=B,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
row={'pid':p.pid,'started':now.isoformat(),'log':str(logpath),'remaining_case':'tp8-lora','remaining_valid_jobs':12,'platform_until':until.isoformat(),'hard_stop':hard.isoformat(),'preserved_complete_pairs':18,'same_pod_and_torch_triton_verified':True}
(R/'resume-launch.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row))
a=B/'AGENTS.md';a.write_text('## Stage2 resumed after explicit user instruction 2026-11-16\nUser asked why stop andexplicitly继续做完,thenconfirmednewplatform22:30. Old20:00wasuserdeadline budgetguard,notexperimenterror. Samepod2tdxx/Torch2.10/CoreX5/Triton3.2verified,8GPUidle,pinnedsourceSHApassed. NewcontrollerPID'+str(p.pid)+',resume-launch.json haslog. OnlyTP8LoRA6pairs12jobsremaining;prior18completepairs(36jobs)reuseaftersealSHAchecks,no repeats. Hardstop22:25,admission22:20,reservewholepair25min;original64GPUh/8hcap retained,pod14:35:38cap22:35:38. FrozenHresource-budget unchanged;ONLYR/admission.jsonnewauthorizedwindowwitholdreceiptpreserved. Prior4case numeric/nativegatespassed. TP4CPTtotal16.7280%/-14.3308%meanandCI-targetPASS;TP4LoRA11.8717%/-10.6119%fail;TP8CPT8.5245%/-7.8549%fail. No heavyCPU/IO/archivewhileTP8LoRAformaltiming. Finishestimated22:05–22:15.\n\n'+a.read_text())
